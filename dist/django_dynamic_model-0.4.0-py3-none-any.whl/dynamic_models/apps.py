from django.apps import AppConfig


class DynamicModelsConfig(AppConfig):
    name = "dynamic_models"
    verbose_name = "Dynamic Models"
